/* Copyright 2023 Dual Tachyon
 * https://github.com/DualTachyon
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

#ifndef APP_ACTION_H
#define APP_ACTION_H

#include <stdbool.h>
#include <stdint.h>

#include "driver/keyboard.h"

void ACTION_Power(void);
void ACTION_Monitor(void);
void ACTION_Scan(bool bRestart);
#ifdef ENABLE_VOX
    void ACTION_Vox(void);
#endif

#ifdef ENABLE_FMRADIO
    void ACTION_FM(void);
#endif
void ACTION_SwitchDemodul(void);

#ifdef ENABLE_FEAT_F4HWN
    void ACTION_RxMode(void);
#ifdef ENABLE_FEAT_F4HWN_FULL_WATCH
    uint8_t ACTION_GetRxMode(void);
    void ACTION_SetRxMode(uint8_t mode);
#endif
    void ACTION_MainOnly(void);
    void ACTION_Ptt(void);
    void ACTION_Wn(void);
    void ACTION_BackLightOnDemand(void);
    void ACTION_BackLight(void);
    void ACTION_Mute(void);
    #ifdef ENABLE_FEAT_F4HWN_AUDIO
        void ACTION_RxA(void);
    #endif
    #ifdef ENABLE_FEAT_F4HWN_RESCUE_OPS
        void ACTION_Power_High(void);
        void ACTION_Remove_Offset(void);
    #endif
    #ifdef ENABLE_FEAT_F4HWN_RXTX_LOG
        void ACTION_RxTxLog(void);
    #endif
#endif

#ifdef ENABLE_FEAT_F4HWN_ACTION_PICKER
#define ACTION_PICKER_TIMEOUT_500MS 10u
extern uint8_t gActionPickerKey;
extern uint8_t gActionPickerSelection[2];
extern uint8_t gActionPickerTimeout_500ms;
bool ACTION_PickerProcessKey(KEY_Code_t key, bool isPressed, bool isHeld);
#endif
bool ACTION_IsAvailable(uint8_t action);
void ACTION_Handle(KEY_Code_t Key, bool bKeyPressed, bool bKeyHeld);

#endif
