# Open Quansheng UV-K5 V3/UV-K1 firmware with 2m and 70cm ARDF support

> [!WARNING]
> Use this firmware at your own risk (entirely). There is absolutely no guarantee that it will work in any way shape or form on your radio(s), it may even brick your radio(s), in which case, you'd need to buy another radio.
Anyway, have fun.

<img src="images/ardf_setup.jpg" width=800 />


## Table of Contents

* [Main Features](#main-ardf-features)
* [Compatible Devices](#compatible-devices)
* [ARDF Feature Manual](#ardf-feature-manual)
* [Firmware Flashing](#firmware-flashing)
* [Headphones](#headphones)
* [Antenna Proposals](#antenna-proposals)

## Main ARDF features:

* AM demodulation
* Manual gain control
* Transmission function completely disabled (safe for non ham radio licenced operators!)
* Active fox and remaining cycle time display
* Beep signal before end of fox cycle
* Fox distance prediction

## Compatible Devices

> [!WARNING]
> There are **new hardware versions out**. **Check carefully** which hardware version do you have **before flashing** any new firmware!

:exclamation: All versions have different processors and need the right firmware and flash tool to run. :exclamation:

> The hardware version of a device usually can be found on the label under the battery:
> <img src="images/version2.jpg" width=800 />

Version 1 devices have no version label, version 2 has "V2", version 3 has "V3" and Software Version 7.x (Menu 53 "VER").

> [!WARNING]
> There are falsely labeled devices out! (Internally V2 but V3 on the label.)
> Please check [this discussion first.](https://github.com/armel/uv-k1-k5v3-firmware-custom/discussions/54)


### Hardware version 1:
* FCC ID "XBPUV-K5"
* Quansheng UV-K5 version 1 :white_check_mark:
* Quansheng UV-K5+ ("UV-5R PLUS") version 1 :heavy_check_mark:
* Quansheng UV-K5(8) version 1 :heavy_check_mark:/ Quansheng UV-K6 version 1 :heavy_check_mark:
* Quansheng UV-K5(99) version 1 :heavy_check_mark:
* Use this project: [Quansheng UV-Kx firmware with ARDF support for hardware version 1](https://github.com/reald/uv-k5-firmware-custom/releases) :white_check_mark:


### Hardware version 2:
* FCC ID "XBPUV-K5"
* Quansheng UV-K5(8) / UV-K5(99) (with FCC ID "XBPUV-K5") version 2 :heavy_check_mark:
* Use this project: [Quansheng UV-Kx firmware with ARDF support for hardware version 2](https://codeberg.org/DL9CAT/uv-k5-firmware-custom_v2/releases) :white_check_mark:


### Hardware version 3:
* FCC ID "XBPUV-K5"
* Quansheng UV-K5(8) / UV-K5(99) version 3 :heavy_check_mark:
* Quansheng UV-K1 / UV-K1(8) :heavy_check_mark:
* Use this project: [Quansheng UV-Kx firmware with ARDF support for hardware version 3](https://github.com/reald/uv-k1-k5v3-firmware-custom/releases) :white_check_mark:

NOT COMPATIBLE:
* Quansheng TK-11 / TK-11(8) :x:
* Similar looking baofeng radios :x:


## ARDF Features Manual

Download a precompiled release in the project repository for your [hardware version](#compatible-devices).


## Firmware Flashing

### Preparation with serial programming cable

You need a quansheng programming cable with an integrated USB to serial converter. Most baofeng cables are working fine, too.

1. Find out which hardware version do you have and which firmware do you need for it. See [compatible devices](#compatible-devices).
1. Backup your settings!
1. Charge battery if almost empty!
1. Press PTT key while turning the radio on. This will NOT work if the programming cable is already plugged. White LED on top MUST turn on.
1. Connect the programming cable NOW
1. Run flash program which fits to your hardware version (see next sections)

### Preparation with USB-C cable

Since UV-Kx hardware version 3 the devices can be flashed with a standard USB-C cable, too.

1. Find out which hardware version do you have and which firmware do you need for it. See [compatible devices](#compatible-devices).
1. Connect the USB-C cable
1. Backup your settings!
1. Charge battery if almost empty!
1. Press PTT key while turning the radio on. White LED on top MUST turn on.
1. Run flash program which fits to your hardware version (see next sections)


#### Flash programs for UV-K5/6 hardware version 1
- [HW Version 1 Webflasher for chrome based browsers](https://egzumer.github.io/uvtools/) (Choose `firmware.packed.bin`)
  - :warning: Do NOT flash V2 or V3 hardware devices with this flasher!
- On linux [k5prog](https://github.com/nica-f/k5prog) can be used: Run `k5prog -b firmware.bin -F -YYY`
- On windows [k5prog_win](https://github.com/OneOfEleven/k5prog-win/raw/refs/heads/main/k5prog_win.exe) can be used. (Choose `firmware.packed.bin`)
- Official quansheng flash tool (Windows only. Choose `firmware.packed.bin`)

#### Flash programs for UV-K5/6 hardware version 2
- There is no working webflasher for this hardware version.
- On linux [k5prog](https://github.com/nica-f/k5prog) can be used: Run `k5prog -b UVK5-V2.ARDF.bin -F -YYY`
- On windows [k5prog_win](https://github.com/OneOfEleven/k5prog-win/raw/refs/heads/main/k5prog_win.exe) can be used. (Choose `UVK5-V2.ARDF.packed.bin`)

#### Flash programs for UV-K5/6 hardware version 3 and K1
- Either programming cable or USB-C cable can be used.
- :warning: k5prog and k5prog_win are NOT compatible.
- [UVTOOLS2 for chrome based browsers](https://armel.github.io/uvtools2/)
  - :warning: Do NOT flash V1 or V2 hardware devices with this flasher!

#### Trouble Shooting
- If device does not boot after flashing something went wrong. Try flashing another firmware file or a different flash tool.
- If serial port is not found on linux add your username to the `dialout` group (`sudo usermod -aG dialout your_username`) and reboot.


## Usage

### Draussenfuchs Quick Setup ###

1. Turn the power knob at least 90° to 120° to switch the device on.
1. Draussenfuchs Mode can be enabled in the menu (ARDF = "DF Simple"). This enables **manual gain control**
stepping by pressing **UP/DOWN keys**. Smaller values have lower sensitivity. Use this close to loud transmitters.
"DF Simple" mode automatically preconfigures the most important settings.
1. Set frequency stepping to 1 kHz. (Menu: Step = 1.00kHz)
1. Select amplitude demodulation (Menu: Mode = AM)
1. Enter frequency (Main Screen: 433920 for 433.920 MHz)

That's it.

<img src="images/df_screen.png" width=400 />

Main screen in "DF Simple" mode. Gain step 6 is used, received signal strength is 062 (the higher the stronger the signal).
A means "VFO A" (can be A or B, does not matter), "AM" means amplitude demodulation (selected in the menu before),
"W" means wide bandwidth (can be "W" or "N", does not really matter). 433.920 is the selected frequency (433.920 MHz).

### ARDF Quick Setup ###

For amateur radio direction finding (ARDF) with timing some more steps are needed:

Turn the power knob at least 90° to switch the device on. (On v3 devices at least 120°).

ARDF Mode can be disabled/enabled in the menu (ARDF = OFF / ARDF / DF Simple). "ARDF" or "DF Simple" enable **manual gain control**
stepping by pressing **UP/DOWN keys**. On step changes the attenuation by approximately 5dB. Index 0
has the smallest sensitivity.
"DF Simple" has a simplified display especially created for [Draussenfuchs](https://draussenfuchs.de) or when no timing is needed.

- Disable squelch (Menu: Sql = 0)
- Disable dual watch (Menu: RxMode = MAIN ONLY).
- Select number of foxes in menu "NumFox" (default = 5, min = 1, max = 10; 0 disables fox timing).
- Choose duration time of one fox transmission in menu "FoxDur". Default is 60s.
Modify with UP/DOWN key in 0.1s steps or enter value as *5 digit number* in 1/100s resolution. Confirm with menu button (min = 001.00s, max = 999.99s).
- Enter beep signal before end of fox cycle time (menu "EndSig", 0s = off, 1..30s).
- Adjust clock correction if necessary (menu "ClkCor", details below).
- Activate VFO A (long pressing key "2 A/B" toggles between both VFOs.
- Enter the frequency of the foxes using the number keys. If memory mode is active long press "3 VFO MR" to change to frequency mode.
- Choose the modulation type of the foxes in menu "Mode" (e.g. AM).
- Switch to VFO B by long pressing "2 A/B". This VFO will mostly be used for the return beacon.
- Configure frequency and modulation the same way as for VFO A.
- Change back to VFO A by long pressing "2 A/B".
- If you want to use distance prediction, calibrate RSSI0 at 100m distance (menu "RSS100", details below).

- Unscrew antenna and add a directional antenna with good front/back ratio.
- Select a medium volume and try not to change it. Volume adjustment should be done with gain control (UP/DOWN keys).
- Listen for foxes, synchronize fox number and timer in menu with "ActFox" and "TiRst" options (details below).
- Start hunting foxes and have fun!


#### Main ARDF Screen ####

<img src="images/ardf_screen.png" width=800 />

This pictures shows the radio screen if ARDF mode is enabled. The battery voltage is 8.54V. The second (big) line shows
active fox (2), seconds left in this fox cycle (5), chosen gain index (0) and the raw received signal strength indicator (RSSI, 151 here).

The **bold line** below show the settings for the **active VFO**:
VFO "A", demodulation "AM", bandwidth mode "W" (wide) and receiving frequency "144.525 MHz".

In the middle the signal strength is shown: -93 dBm / S9 and a strength bar. The value at the end of the line is called *RSSI0* (151). It is
used for distance calculation and distance calibration. It adds the influence of the selected attenuation (gain index) to the raw RSSI value.

For the active VFO (A) the gain remember mode (details below) is active so the gain index history table for up to 5 foxes is shown. The active fox number is bold.
The last column behind the gain remember table shows a rough prediction of the distance to the fox (100m).
It is roughly estimated out of the normalized signal strength "RSSI0".
If the received signal is too weak no prediction is shown.

The last line shows the configuration for the **inactive VFO**. It is recommended to put the fox settings in VFO A and the return beacon on VFO B.
By long pressing "2 A/B" key can quickly be switched between both configurations.

The manual gain index (attenuation) value can be chosen with UP/DOWN keys. Smaller values mean more attenuation. Use smaller values if you get closer to a transmitter.

Because hardware version 3 has less attenuation dynamic than its predecessors, negative gain indexes were introduced:
  * -1 disables the input LNA
  * -2 and -3 tune to the second/third harmonic frequency (if the radio can receive this range)

All methods give you a huge additional attenuation and can be used to prevent overdriving the receiver.
Use this only close to a transmitter if the RSSI value is rising above 200.
Be aware that the radiation pattern of your antenna might be different when receiving harmonics.

On system boot the device starts with active fox number 1 and full duration time left. In menu "ActFox" the active fox can be changed.
The timer can be reset in menu "TiRst". Select "TiRst" with "M"-key, a triangle appears. Another press on "M"-key will reset the timer.
Use this for synchronization. Active fox and timer are shown on the top in the status bar if the menu is opened.

To get a notice if the fox cycle is ending soon a beep sound can be played. The number of seconds for this tone before
the ending of a fox cycle can be configured in menu "EndSig" (1..30s or "off" for no signal). Please read the [headphone section](#headphones)
before activating this feature with headphones.


#### Gain Remember Mode ####
This firmware supports **gain remember** for manual gain control. If gain remember is activated, the
**manual gain index** is handled **for every fox separately**. At the **beginning of a fox cycle** the **last gain
index for this fox** is **restored from the last cycle**. The manual gain index history table for up to 5 foxes is shown
in the lower part of the screen.

If gain remember is **off**, there is only one gain index for all foxes independent from any fox cycle times.
This feature can be **configured for both VFOs separately** (menu "GainRe": Off / VFO A / VFO B / BOTH).

A usage scenario would be to configure the fox frequency on VFO A with gain remember mode on. Put the return beacon
frequency on VFO B without gain remember on. (The return beacon is transmitting permanently so there is no need for
different gains in different time slots.)

You can quickly switch between both VFOs by long pressing "2 (A/B)" or a configured function key (see below).

If gain remember is not activated on the actual VFO or "no timing" is selected (NumFox=0), no gain index history is shown in the lower part of the screen.


#### Distance prediction and calibration ####
The distance to the fox is calculated out of a simple model: A change of 30dB in signal strength in a forest is a factor of 10 in distance. This is only
a rough model. The real signal strength highly depends on the topology of the area and can vary a lot especially in hilly areas. So don´t overestimate
the predicted value.

The signal strength highly depends on the real transmitted power of the fox and the antenna at your receiver. To calibrate this combination place yourself
100m away from a transmitting fox. Choose a gain index as low as possible (preferable 0, but NOT negative!). Point your antenna directly to the fox.
Watch the RSSI0 value (right from the signal strength bar, above the predicted distance) if the fox is transmitting its identifier. Enter the
observed peak value in the "RSS100" menu.
If the shown distance values are too low, increase the value of RSS100. If the shown distance values are too high, decrease the value of RSS100.
The resolution is 0.5dB. A value of 0 disables distance prediction completely.


#### Clock Correction ####
The microcontroller of the radio has no crystal oscillator and runs on an internal 48 MHz resonator only.
So all timers in the CPU are not very precise. This leads to a heavily drifting clock.

> [!Note]
> If no timing is used (e.g. in ARDF="DF Simple" mode) clock correction is **not** necessary.

The firmware provides a correction
mechanism to reach acceptable ranges. Start ARDF mode and stop **how many seconds really pass** until **the radio tells 1 hour is up**.
(Useful settings: NumFox = 10, FoxDur = 60.00s, sync to reference clock.) The formula for the correction value is:

$$ CorrectionValue = 6000 - (StoppedSeconds * 100)/60 $$

E.g. if the radio finished 60 one minute cycles in 59 min and 36 seconds = 59 * 60 + 36 = 3576s the calculation would be:

$$ CorrectionValue = 6000 - (3576 * 100)/60 = 40 $$

Enter this value in menu "ClkCor" using UP/DOWN keys (allowed range: -500 ... 500). The value is stored in eeprom.


#### Function keys ####
Two different ARDF actions can be mapped to function keys:
* Set manual gain to a medium index value (4). It is recommended to configure "ARDF Set Med.Gain" to short press on F2 key, menu: F2Shrt)
* Enable/Disable ARDF function (e.g. for long press on F1 key / menu: F1Long = "ARDF off/on").

It is recommended to configure "Switch VFO" to F1 short (menu F1Shrt).


#### Chirp ####
A [chirp](https://chirpmyradio.com/projects/chirp/wiki/Home) module is shipped with every firmware release.
The radio (including ARDF settings) can be programmed only with this module and not with the standard UV-Kx chirp module.

#### Notes ####
* The lowest possible frequency of the receiver chip is 18 MHz. So this is NOT usable on 80 m.
* In ARDF mode any TX functionality is disabled. However it is recommended to compile with ENABLE_PREVENT_TX=1 to
permanently disable TX. This is done for official releases. ARDF receivers with a builtin TX functionality are not permitted
in official competitions anyway.
* You can glue an arrow on the volume knob to keep the position under control (simply cut a triangle from a sticker).
* It is possible (but not recommended because it is more complicated) to use memory mode instead of frequency mode on each VFO.
If memory mode is active on the current VFO, frequency and memory number are are displayed alternately one after each other.
Number keys change the memory number (enter 3 digits)  and not the frequency. You can switch between memory mode and
frequency mode by long pressing "3 VFO/MR" key.
* If you modify settings in memory mode don´t forget to save them before switching off (menu "ChSave").
* You can long press F/# to lock the keypad. If keypad is locked a small lock symbol in the top status bar is shown.
As result in ARDF mode only manual gain control (with up/down keys) and "Switch VFO" and "ARDF Medium Gain"
on the function keys is possible (if configured, see [Function keys](#function-keys)). So ARDF function is possible but no configuration
changes can be done. This can be useful if preconfigured devices are handed to non experienced users. To unlock the keypad just hold F/# key.

#### Troubleshooting ####
* The gain index history is flickering.
  * Disable dual watch (RxMode = MAIN ONLY).
* Only 3 digits are accepted when entering a frequency.
  * The active channel is in memory mode. Long press "3 VFO MR" to change to frequency mode.
* The entered frequency is modified.
  * Decrease frequency step in menu "Step" to desired channel raster (e.g. 1.00 kHz).
* Chirp does read different channel settings than in my radio.
  * If you changed channel settings on the radio you have to store them first (menu "ChSave").
* Signals are all very low, antenna does not respond to rotation movement.
  * Increase volume knob to 90 degree position or more.
* After activating "DF Simple" and switching back to "ARDF" mode the gain remember table is not shown.
  * Reactivate Fox Timing (NumFox > 1) and Gain Remember (GainRe) for the desired VFO
* UP and Down Keys are swapped on UV-K5 V3.
  * K1 settings are selected. Change menu point "SetNav" from „LEFT RIGHT UV-K1“ to „UP DOWN UV-K5(8)“.
    * Before release 0.4 this had to be done in the hidden menu: Hold PTT and SIDE BUTTON 1️⃣ and switch the device on. Release both keys. Change "SetNav" Settings. Restart device.
* Uploading configuration to radio fails in chirp ("Header short read")
  * Try different USB-C cables and different USB ports.


## Headphones

Headphones can be connected to the 2.5mm jack. The audio signal is between the tip and sleeve of the jack, but
there are some limitations:

> [!WARNING]
> **There is a DC voltage of around 4V (half battery voltage) between tip and sleeve**. Use a DC blocker before connecting your headphones to the device!
> Your **headphones might be destroyed** otherwise!

To make it even worse the DC voltage is switched off and on when playing signal tones (fox cycle end warning beep). This leads to
voltage peaks and crackling noises in your headphones.

Use a DC blocking capacitor for removing the DC voltage from the audio signal:
<img src="images/headphone_adapter.png" width=800 />

Both headphone channels are connected in parallel. The needed capacity depends on your headphones.
Try inline capacitor values of 0.1uF .. 10uF as a start. For my 8 ohms (2x 16 ohms parallel) headphones
1 uF works quite well.

> [!Warning]
> Use cheap headphones or some you can go without only!!!

> [!TIP]
> A kenwood connector with a combined 2.5 and 3.5mm plug is mechanically more stable than a single 2.5mm stereo plug.

> [!TIP]
> Kenwood connectors with spiral cable can be taken from cheap external baofeng microphones.

> [!TIP]
> Experienced people in SMD soldering can add the capacitor [inside the device](https://github.com/ludwich66/Quansheng_UV-K5_Wiki/wiki/Hardware_Mods#5-fix-power-failure-with-external-handset-warming-speaker-with-dc-on-output-or-unwanted-busy-channel-lockout-effect-on-external-ptt).
> With this modification a normal 2.5mm stereo plug to 3.5mm stereo jack adapter cable is sufficient.


## Antenna proposals

### 3 Element Yagi for 2m by DK7ZB

<img src="images/dk7zb_el_2m_yagi.jpg" width=600 />
<img src="images/20250619_115524_2m_3el_dk7zb_50ohm_horizontal_standort2_diagr.png" />

Pro: Very easy and fast to build, tolerant, very good SWR, light weight, cheap.

Cons: Front to back ratio not optimal (but not bad!), radials move on boom if not secured.

| Element | Length | Position |
| --- | --- | --- |
| Reflector | 103.9cm | 0 cm |
| Radiator | 102 cm | 30 cm |
| Director | 92,6 cm | 47 cm |

[Build instructions by DK7ZB](https://www.qsl.net/dk7zb/PVC-Yagis/3-Ele-2m.htm)


### 3 Element Tape Measure Antenna for 2m ARDF

<img src="images/ardf_setup.jpg" width=600 />
<img src="images/20250619_112008_2m_ma_band_horizontal_diagr.png" width=600 />

Pro: Better front to back ratio, flexible elements better when running in the fields. Standard ARDF antenna!

Cons: More complex to build, not suitable for TX because of missing adaption.

Tip: Use 2 layers of tape measure. Outer 25cm can be single layer.

| Element | Length | Position |
| --- | --- | --- |
| Reflector | 106.5cm | 0 cm |
| Radiator | 2*47cm | 20 cm |
| Director | 90,5 cm | 52 cm |

#### 3D printed Mechanical solution by DL7CR ####
<img src="images/ant_2m_dl7cr.jpg" width=600 />

Pro: Comfortable 3D printed solution with 16mm PCV pipe.

Cons: Pressing buttons needs 2 hands

Uses [pawsay stub](https://www.dg7ybn.de/Symmetrising/Symmetrising.htm#Pawsey_Stub_Symmetrising_Device) as balun.

Download [Freecad model here](images/ARDF2_Ant.FCStd).



### 3 Element Tape Measure Yagi for 70 cm
<img src="images/70cm_3el_tapemeasure.jpg" width=600 />
<img src="images/70cm_3el_tapemeasure_radiation_pattern.jpg" width=600 />


Made out of 12mm tape measure. Designed for Draussenfuchs Project.

Pro: Very good F/B ratio, light weight (70g), cheap, foldable.

[3d printed parts available here.](https://www.printables.com/model/1757409-3-element-yagi-direction-finding-antenna-for-70cm)

| Element | Length | Position |
| --- | --- | --- |
| Reflector | 34.6 cm | 0 cm |
| Radiator | 30 cm | 12 cm |
| Director | 28 cm | 23 cm |



### 3 Element Yagi for 70 cm
<img src="images/70cm_3el_optim.jpg" width=600 />
<img src="images/20250705_103756_3el_yagi_optim_horizontal_standort3_diagr.png" width=600 />

Made out of 3.2mm welding rods.

Pro: Quite nice F/B ratio, light weight.

Cons: Thin rods not so suitable for younger children.

| Element | Length | Position |
| --- | --- | --- |
| Reflector | 35 cm | 0 cm |
| Radiator | 32,6 cm | 12 cm |
| Director | 30 cm | 23 cm |


### 3 Element Tape measure Yagi for 70 cm (DF9NX)
<img src="images/df9nx_yagi_3dprint.jpg" width=600 />

[3d printed mounts](https://github.com/reald/uv-k5-firmware-custom/raw/refs/heads/main/images/df9nx_70cm_3dfiles.zip) for tape measure elements (19mm) on 10mm aluminium u-profile.
Driven simply in center of radiator. RG174 cable and M3x12mm screws.

Pro: Radio and antenna combined.

Cons: Not for TX.

| Element | Length | Position |
| --- | --- | --- |
| Reflector | 34 cm | 0 cm |
| Radiator | 32,5 cm | 12.6 cm |
| Director | 29.5 cm | 18 cm |


### 3 Element cable Yagi for 70 cm (DF9NX)
<img src="images/df9nx_yagi_cable.jpg" width=600 />

[3d printed mounts](https://github.com/reald/uv-k5-firmware-custom/raw/refs/heads/main/images/df9nx_yagi_cable_3dfiles.zip) for electric cable elements on 10mm aluminium u-profile.
Driven simply in center of radiator.

Pro: Radio and antenna combined, very light weight.

Cons: Not for TX, elements might bend.

| Element | Length | Position |
| --- | --- | --- |
| Reflector | 38 cm | 0 cm |
| Radiator | 30 cm | 8.5 cm |
| Director | 27 cm | 14 cm |


### Combined 2m / 70cm Antenna by PA0JBG

<img src="images/combined_2m_70cm_antenna_PA0JBG_ARDF_social.darc.de.jpg" width=600 />

Notes: This prototype has a switchable attenuator (approx. 25dB), this is optional. Boom is made of electrical conducting material.

2 m:
| Element | Length | Position |
| --- | --- | --- |
| Reflector | 106 cm | 0 cm |
| Radiator | 94 cm | 20 cm |
| Director | 90 cm | 51.5 cm |

70 cm:
| Element | Length | Position |
| --- | --- | --- |
| Reflector | 34,8 cm | 0 cm |
| Radiator | 31 cm | 14,5 cm |
| Director 1 | 30,2 cm | 19 cm |
| Director 2 | 29,8 cm | 31,5 cm |
| Director 3 | 29,2 cm | 46 cm |


### Other

- [3D printed 3 element draussenfuchs yagi by DG1JAN](https://www.printables.com/model/1698556-draussenfuchs-yagi)


